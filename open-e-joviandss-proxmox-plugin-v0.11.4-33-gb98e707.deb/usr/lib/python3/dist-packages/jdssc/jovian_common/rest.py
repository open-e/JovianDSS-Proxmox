#    Copyright (c) 2024 Open-E, Inc.
#    All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.


"""REST cmd interoperation class for Open-E JovianDSS driver."""
import re
import time
import random

import logging

from jdssc.jovian_common import exception as jexc
from jdssc.jovian_common import rest_proxy
from jdssc.jovian_common.stub import _

from jdssc.jovian_common import jdss_common as jcom
import jdssc.lock as jlock

LOG = logging.getLogger(__name__)


class JovianRESTAPI(object):
    """Jovian REST API"""

    def __init__(self, config):

        self.pool = config.get('jovian_pool', 'Pool-0')
        self.configuration = config
        self.rproxy = rest_proxy.JovianDSSRESTProxy(config)

        self.resource_dne_msg = (
            re.compile(r'^Zfs resource: .* not found in this collection\.$'))

        self.resource_has_clones_msg = (
            re.compile(r'^In order to delete a zvol, you must delete all of '
                       'its clones first.$'))
        self.resource_has_clones_class = (
            re.compile(r'^opene.storage.zfs.ZfsOeError$'))

        self.resource_has_clones2_class = (
            re.compile(r'^opene.storage.zfs.zfs.ZfsOeError$'))

        self.resource_has_snapshots_msg = (
            re.compile(r"^cannot destroy '.*/.*': volume has children\nuse "
                       r"'-r' to destroy the following datasets:\n.*"))

        self.zfs_cmd_error_class = (
            re.compile(r'^zfslib.wrap.zfs.ZfsCmdError$'))

        self.class_cfg_parser_error = (
            re.compile(r'^opene\.cfgparser\.CfgParserError$'))

        self.class_werkzeug_notfound = (
            re.compile(r'werkzeug.exceptions.NotFound'))

        self.class_zfsresourceerror = (
            re.compile(r'^zfslib.zfsapi.resources.ZfsResourceError$'))

        self.class_item_not_found_error = (
            re.compile(r"^opene.exceptions.ItemNotFoundError$"))

        self.class_item_conflict_error = (
            re.compile(r'^opene.exceptions.ItemConflictError$'))

        self.message_volume_already_used = (
            re.compile(r'^Volume .* is already used.$'))

        self.message_dataset_do_not_exist = (
            re.compile(r"^cannot open '.*': dataset does not exist$"))

        self.resource_already_exists_msg = (
            re.compile(r"^Resource .* already exists.$"))

        self.message_share_already_exists_msg = (
            re.compile(r"^Share .* already exists.$"))

        self.message_share_not_exists_msg = (
            re.compile(r"^Share .* not exists.$"))

        self.message_clone_not_exists_msg = (
            re.compile(r"^Clone .* not exists$"))

        self.dataset_exists_msg = (
            re.compile(r"^cannot create '.*': dataset already exists$"))

        self.no_space_left = (
            re.compile(r"^New zvol size\(\d+\) exceeds available space on pool"
                       r" .+\(\d+\).$"))

        self.message_vip_allowed_portals_not_supported = (
            re.compile((r"^Additional properties are not allowed \('vip_allowed_portals' was unexpected\)$")))

    def _general_error(self, url, resp):
        reason = "Request %s failure" % url
        LOG.debug("error resp %s", resp)
        if 'error' in resp:

            eclass = resp['error'].get('class', 'Unknown')
            code = resp['error'].get('code', 'Unknown')
            msg = resp['error'].get('message', 'Unknown')

            reason = _("Request to %(url)s failed with code: %(code)s "
                       "of type: %(eclass)s reason: %(message)s")
            reason = (reason % {'url': url,
                                'code': code,
                                'eclass': eclass,
                                'message': msg})
        raise jexc.JDSSException(reason=reason)

    def _lock(self):
        """Acquire iSCSI target lock. Returns lock path.

        iscsi_target_lock_path must always be present in configuration —
        bin/jdssc sets it unconditionally via unify_config_options. If it is
        absent, someone removed a required part of the locking setup.
        """
        lock_path = self.configuration.get('iscsi_target_lock_path')
        if not lock_path:
            raise RuntimeError(
                "iscsi_target_lock_path missing from configuration; "
                "iSCSI target locking has been misconfigured or disabled"
            )
        return jlock.acquire_target_lock(
            lock_path,
            self.configuration.get(
                'lock_timeout', jlock.MAX_ISCSI_CHANGE_LOCK_TIMEOUT),
        )

    def get_active_host(self):
        """Return address of currently used host."""
        return self.rproxy.get_active_host()

    def is_pool_exists(self):
        """is_pool_exists.

        GET
        /pools/<string:poolname>

        :param pool_name:
        :return: Bool
        """
        req = ""
        LOG.debug("check pool")

        resp = self.rproxy.pool_request('GET', req)

        if resp["code"] == 200 and not resp["error"]:
            return True

        return False

    def get_iface_info(self):
        """get_iface_info

        GET
        /network/interfaces
        :return list of internet ifaces
        """
        req = '/network/interfaces'

        LOG.debug("get network interfaces")

        resp = self.rproxy.request('GET', req)
        if (resp['error'] is None) and (resp['code'] == 200):
            return resp['data']
        self._general_error(req, resp)

    def get_volumes_page(self, page_id):
        """get_volumes_page

        GET
        /pools/<string:poolname>/volumes?page=<string:page_id>
        :page_id pool_name
        :return list volumes at page X of pool
        """
        req = '/volumes?page=%s&per_page=100' % str(page_id)

        LOG.debug("get page %d of all volumes", page_id)

        max_retries = 10
        for attempt in range(max_retries):
            resp = self.rproxy.pool_request('GET', req)

            if not resp["error"] and resp["code"] == 200:
                if isinstance(resp["data"], dict) and "entries" in resp["data"]:
                    return resp["data"]["entries"]
                delay = random.uniform(1, 5)
                LOG.warning("get_volumes_page: unexpected response format "
                            "(attempt %d/%d), retrying in %.1fs: %s",
                            attempt + 1, max_retries, delay, resp["data"])
                time.sleep(delay)
                continue

            if attempt < max_retries - 1:
                delay = random.uniform(1, 5)
                LOG.warning("get_volumes_page: request failed "
                            "(attempt %d/%d), retrying in %.1fs",
                            attempt + 1, max_retries, delay)
                time.sleep(delay)
                continue

            self._general_error(req, resp)

    def create_lun(self, volume_name, volume_size, sparse=False,
                   block_size=None):
        """create_volume.

        POST
        .../volumes

        :param volume_name:
        :param volume_size:
        :param sparse: thin or thick volume flag
        :param block_size: size of block
        :return:
        """
        volume_size_str = str(volume_size)
        jbody = {
            'name': volume_name,
            'size': volume_size_str,
            'sparse': sparse
        }
        if block_size:
            jbody['blocksize'] = block_size

        req = '/volumes'

        LOG.info("create volume %(vol)s of size %(size)s%(sparse)s",
                 {'vol': jcom.idname(volume_name),
                  'size': volume_size_str,
                  'sparse': ' that is sparse' if sparse else ''})

        resp = self.rproxy.pool_request('POST', req, json_data=jbody)

        LOG.debug("response is %s", str(resp))
        if resp["code"] in (200, 201):
            # TODO: should we check for presence of error for this call
            return

        if "error" in resp and resp["error"] is not None:
            if "errno" in resp['error']:
                if resp["error"]["errno"] == str(5):
                    self._general_error(req, resp)
            if "message" in resp["error"]:
                if self.no_space_left.match(resp["error"]["message"]):
                    raise jexc.JDSSResourceExhausted
                if self.resource_already_exists_msg.match(
                        resp["error"]["message"]):
                    raise jexc.JDSSVolumeExistsException(volume_name)
                if self.dataset_exists_msg.match(resp["error"]["message"]):
                    raise jexc.JDSSDatasetExistsException(volume_name)
        self._general_error(req, resp)

    def extend_lun(self, volume_name, volume_size):
        """create_volume.

        PUT /volumes/<string:volume_name>
        """
        req = '/volumes/' + volume_name
        volume_size_str = str(volume_size)
        jbody = {
            'size': volume_size_str
        }

        LOG.info("extend volume %(volume)s to %(size)s",
                 {"volume": jcom.idname(volume_name),
                  "size": volume_size_str})
        resp = self.rproxy.pool_request('PUT', req, json_data=jbody)

        if not resp["error"] and resp["code"] == 201:
            return

        if resp["error"]:
            raise jexc.JDSSRESTException(req,
                                         _('Failed to extend volume %s' %
                                           volume_name))

        self._general_error(req, resp)

    def is_lun(self, volume_name):
        """is_lun.

        GET /volumes/<string:volumename>
        Returns True if volume exists. Uses GET request.
        :param pool_name:
        :param volume_name:
        :return:
        """
        req = '/volumes/' + volume_name

        LOG.debug("check volume %s", volume_name)
        ret = self.rproxy.pool_request('GET', req)

        if not ret["error"] and ret["code"] == 200:
            return True
        return False

    def get_lun(self, volume_name):
        """get_lun

        GET /volumes/<volume_name>
        :param volume_name: zvol id
        :return: volume dict
            {
                "origin": null,
                "referenced": "65536",
                "primarycache": "all",
                "logbias": "latency",
                "creation": "1432730973",
                "sync": "always",
                "is_clone": false,
                "dedup": "off",
                "used": "1076101120",
                "full_name": "Pool-0/v1",
                "type": "volume",
                "written": "65536",
                "usedbyrefreservation": "1076035584",
                "compression": "lz4",
                "usedbysnapshots": "0",
                "copies": "1",
                "compressratio": "1.00x",
                "readonly": "off",
                "mlslabel": "none",
                "secondarycache": "all",
                "available": "976123452576",
                "resource_name": "Pool-0/v1",
                "volblocksize": "131072",
                "refcompressratio": "1.00x",
                "snapdev": "hidden",
                "volsize": "1073741824",
                "reservation": "0",
                "usedbychildren": "0",
                "usedbydataset": "65536",
                "name": "v1",
                "checksum": "on",
                "refreservation": "1076101120"
            }
        """
        req = '/volumes/' + volume_name

        LOG.debug("get volume %s info", volume_name)
        resp = self.rproxy.pool_request('GET', req)

        if not resp['error'] and resp['code'] == 200:
            return resp['data']

        if resp['error']:
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(res=volume_name)

        self._general_error(req, resp)

    def modify_lun(self, volume_name, prop=None):
        """Update volume properties

        :param volume_name: volume name
        :param prop: dictionary
            {
                <property>: <value>
            }
        """

        req = '/volumes/' + volume_name

        LOG.info("update volume %(vol)s properties %(prop)s",
                 {'vol': jcom.idname(volume_name),
                  'prop': str(prop)})
        resp = self.rproxy.pool_request('PUT', req, json_data=prop)

        if resp["code"] in (200, 201, 204):
            LOG.debug("volume %s updated", volume_name)
            return

        if 'code' in resp and 'error' in resp:
            if resp["code"] == 500 and resp["error"] is not None:
                if 'errno' in resp['error']:
                    if resp["error"]["errno"] == 1:
                        raise jexc.JDSSResourceNotFoundException(
                            res=volume_name)
                    elif resp["error"]["errno"] == 13:
                        if 'class' in resp['error']:
                            if self.class_cfg_parser_error.match(
                                    resp['error']['class']):
                                if 'message' in resp['error']:
                                    raise jexc.JDSSCfgParserException(
                                        resp['error']['message'])
                                else:
                                    raise jexc.JDSSCfgParserException(
                                        "Unknown cfg error")

        self._general_error(req, resp)

    def make_readonly_lun(self, volume_name):
        """Set volume into read only mode

        :param: volume_name: volume name
        """
        prop = {"property_name": "readonly", "property_value": "on"}

        self.modify_property_lun(volume_name, prop)

    def modify_property_lun(self, volume_name, prop=None):
        """Change volume properties

        :param volume_name: volume name
        :param prop: dictionary of volume properties in format
                { "property_name": "<name of property>",
                  "property_value":"<value of a property>"}
        """

        req = '/volumes/%s/properties' % volume_name

        LOG.info("set volume %(vol)s propertie %(prop)s to %(value)s",
                 {'vol': jcom.idname(volume_name),
                  'prop': str(prop['property_name']),
                  'value': str(prop['property_value'])})
        resp = self.rproxy.pool_request('PUT', req, json_data=prop)

        if resp["code"] in (200, 201, 204):
            LOG.debug(
                "volume %s properties updated", volume_name)
            return

        if resp["code"] == 500:
            if resp["error"] is not None:
                if resp["error"]["errno"] == 1:
                    raise jexc.JDSSResourceNotFoundException(
                        res=volume_name)
        self._general_error(req, resp)

    def delete_lun(self, volume_name,
                   recursively_children=False,
                   force_umount=False):
        """delete_volume.

        DELETE /volumes/<string:volumename>
        :param volume_name:
        :return:
        """
        jbody = {}
        if recursively_children:
            jbody['recursively_children'] = True

        if force_umount:
            jbody['force_umount'] = True

        req = '/volumes/' + volume_name
        LOG.info(("delete volume: %(vol)s"
                  " recursively" if recursively_children else ""
                  " with unmounting" if force_umount else ""),
                 {'vol': jcom.idname(volume_name)})

        if len(jbody) > 0:
            resp = self.rproxy.pool_request('DELETE', req, json_data=jbody)
        else:
            resp = self.rproxy.pool_request('DELETE', req)

        if resp["code"] == 204:
            LOG.debug(
                "volume %s deleted", volume_name)
            return

        # Handle "does not exist" case
        if resp["code"] == 500:
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    LOG.debug("volume %s do not exists, delition success",
                              volume_name)
                    return

        # Handle volume busy
        if resp["code"] == 500 and resp["error"]:
            if 'message' in resp['error'] and \
               'class' in resp['error']:
                if (self.resource_has_clones_msg.match(
                        resp['error']['message']) and
                   (self.resource_has_clones_class.match(
                        resp['error']['class']) or
                   self.resource_has_clones2_class.match(
                        resp['error']['class']))):
                    LOG.warning("volume %s is busy", volume_name)
                    raise jexc.JDSSResourceIsBusyException(res=volume_name)
                if (self.resource_has_snapshots_msg.match(
                        resp['error']['message']) and
                   self.zfs_cmd_error_class.match(
                        resp['error']['class'])):
                    LOG.warning("volume %s is busy", volume_name)
                    raise jexc.JDSSResourceIsBusyException(res=volume_name)
        if 'error' in resp and resp["error"] is not None:
            if 'message' in resp['error'] and \
               'class' in resp['error']:
                if (self.resource_has_clones_msg.match(
                        resp['error']['message']) and
                   (self.resource_has_clones_class.match(
                        resp['error']['class']) or
                   self.resource_has_clones2_class.match(
                        resp['error']['class']))):
                    LOG.warning("volume %s is busy", volume_name)
                    raise jexc.JDSSResourceIsBusyException(res=volume_name)

        if resp.get("code") == 500 and resp.get("error") is not None:
            if resp["error"].get("errno") == 13:
                if 'class' in resp["error"] and \
                        self.class_cfg_parser_error.match(resp["error"]["class"]):
                    msg = resp["error"].get("message", "Unknown cfg error")
                    raise jexc.JDSSCfgParserException(msg)

        self._general_error(req, resp)

    def is_target(self, target_name):
        """is_target.

        GET /san/iscsi/targets/ target_name
        :param target_name:
        :return: Bool
        """
        req = '/san/iscsi/targets/' + target_name

        LOG.debug("check if targe %s exists", target_name)
        resp = self.rproxy.pool_request('GET', req)

        if resp:
            if "error" in resp:
                if resp["error"] or resp["code"] not in (200, 201):
                    return False

            if "name" in resp["data"]:
                if resp["data"]["name"] == target_name:
                    LOG.debug(
                        "target %s exists", target_name)
                    return True

        return False

    def create_target(self,
                      target_name,
                      assigned_vips,
                      use_chap=True,
                      allow_ip=None,
                      deny_ip=None):
        """create_target.

        POST /san/iscsi/targets
        :param target_name:
        :param chap_cred:
        :param allow_ip:
        "allow_ip": [
                "vip-name-1",
                "vip-name-2"
            ],

        :return:
        """
        req = '/san/iscsi/targets'

        jdata = {"name": target_name, "active": True}

        jdata["incoming_users_active"] = use_chap

        if allow_ip:
            jdata["allow_ip"] = allow_ip

        if deny_ip:
            jdata["deny_ip"] = deny_ip

        vip_allowed_portals = {'enabled': True,
                               'assigned_vips': assigned_vips}
        if vip_allowed_portals:
            jdata['vip_allowed_portals'] = vip_allowed_portals

        LOG.info("create iSCSI target: %(target)s",
                 {'target': target_name})

        # lock_path = self._lock()
        # try:
        resp = self.rproxy.pool_request(
            'POST', req, json_data=jdata, apiv=4)
        # finally:
        #    jlock.release_target_lock(lock_path)

        if not resp["error"] and resp["code"] == 201:
            return

        if resp["code"] == 409:
            raise jexc.JDSSResourceExistsException(res=target_name)

        if 'error' in resp:
            if 'message' in resp['error']:
                if self.message_vip_allowed_portals_not_supported.match(
                        resp['error']['message']):
                    raise jexc.JDSSOutdated("VIP Restriction")
        self._general_error(req, resp)

    def delete_target(self, target_name):
        """delete_target.

        DELETE /san/iscsi/targets/<target_name>
        :param pool_name:
        :param target_name:
        :return:
        """
        req = '/san/iscsi/targets/' + target_name

        LOG.info("delete iSCSI target: %(target)s",
                 {'target': target_name})

        # lock_path = self._lock()
        # try:
        resp = self.rproxy.pool_request('DELETE', req)
        # finally:
        #    jlock.release_target_lock(lock_path)

        if resp["code"] in (200, 201, 204):
            LOG.debug(
                "target %s deleted", target_name)
            return

        not_found_err = "opene.exceptions.ItemNotFoundError"
        if (resp["code"] == 404) or \
                (resp["error"]["class"] == not_found_err):
            raise jexc.JDSSResourceNotFoundException(res=target_name)

        self._general_error(req, resp)

    def create_target_user(self, target_name, chap_cred):
        """Set CHAP credentials for accees specific target.

        POST
        /san/iscsi/targets/<target_name>/incoming-users

        :param target_name:
        :param chap_cred:
        {
            "name": "target_user",
            "password": "3e21ewqdsacxz" --- 12 chars min
        }
        :return:
        """
        req = "/san/iscsi/targets/%s/incoming-users" % target_name

        LOG.debug("add credentails to target %s", target_name)

        # lock_path = self._lock()
        # try:
        resp = self.rproxy.pool_request('POST', req, json_data=chap_cred)
        # finally:
        #    jlock.release_target_lock(lock_path)

        if not resp["error"] and resp["code"] in (200, 201, 204):
            return

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=target_name)

        self._general_error(req, resp)

    def get_target(self, target_name):
        """get target data

        GET
        /san/iscsi/targets/<target_name>

        :return list of all iscsi targets related to pool
        """
        req = "/san/iscsi/targets/%s" % target_name

        LOG.debug("get target %s", target_name)
        resp = self.rproxy.pool_request('GET', req, apiv=4)

        if resp['error'] is None and resp['code'] == 200:
            return resp['data']

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=target_name)
        self._general_error(req, resp)

    def get_target_sessions(self, target_name):
        """get_target_sessions

        GET
        /san/iscsi/targets/<target_name>/sessions

        :param target_name: full iSCSI target IQN
        :return: list of active session dicts, each with keys:
            target_name, cid, ip, sid, initiator_name
        """
        req = "/san/iscsi/targets/%s/sessions" % target_name

        LOG.debug("get sessions for target %s", target_name)
        resp = self.rproxy.pool_request('GET', req, apiv=4)

        if resp['error'] is None and resp['code'] == 200:
            return resp['data']

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=target_name)
        self._general_error(req, resp)

    def set_target_incoming_users_active(self, target_name, active):
        """Update incoming_users_active flag on an existing target.

        PUT /san/iscsi/targets/<target_name>

        :param target_name: target name
        :param active: True to require CHAP, False to disable
        """
        req = "/san/iscsi/targets/%s" % target_name
        jdata = {"name": target_name, "incoming_users_active": active}

        LOG.debug("set iSCSI target %s incoming_users_active=%s",
                  target_name, active)

        # lock_path = self._lock()
        # try:
        resp = self.rproxy.pool_request(
            'PUT', req, json_data=jdata, apiv=4)
        # finally:
        #    jlock.release_target_lock(lock_path)

        if resp['error'] is None and resp['code'] in (200, 201, 204):
            return

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=target_name)
        self._general_error(req, resp)

    def set_target_assigned_vips(self, target_name, assigned_vips):
        """set target assigned vips

        This function also enables vip allowed portal property

        PUT
        /san/iscsi/targets/<target_name>

        :return list of all iscsi targets related to pool
        """
        req = "/san/iscsi/targets/%s" % target_name

        jdata = {"name": target_name}

        vip_allowed_portals = {'enabled': True,
                               'assigned_vips': assigned_vips}
        jdata['vip_allowed_portals'] = vip_allowed_portals

        LOG.info("set iSCSI target: %(target)s assigned vips "
                 "to %(assigned_vips)s",
                 {'target': target_name,
                  'assigned_vips': ','.join(assigned_vips)})

        # lock_path = self._lock()
        # try:
        resp = self.rproxy.pool_request(
            'PUT', req, json_data=jdata, apiv=4)
        # finally:
        #    jlock.release_target_lock(lock_path)

        if resp['error'] is None and resp['code'] in (200, 201, 204):
            return resp['data']

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=target_name)
        self._general_error(req, resp)

    def get_targets(self):
        """get_all_pool_volumes.

        GET
        /san/iscsi/targets

        :return list of all iscsi targets related to pool
        """
        req = "/san/iscsi/targets"

        LOG.debug("get all targets")
        resp = self.rproxy.pool_request('GET', req, apiv=4)

        if resp['error'] is None and resp['code'] == 200:
            return resp['data']
        self._general_error(req, resp)

    def get_target_luns(self, target_name):
        """Get list of luns attached to target

        GET
        /san/iscsi/targets/<target_name>/luns

        :param target_name:
        """
        req = "/san/iscsi/targets/%s/luns" % target_name

        LOG.debug("get target %s luns", target_name)

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp['data']

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=target_name)

        self._general_error(req, resp)

    def get_target_by_lun_name(self, volume_name):
        """Get iSCSI LUN entries for a volume across all targets and pools.

        GET /san/iscsi/luns?where=name=={volume_name}

        :param volume_name: physical volume name to search for
        :return: list of dicts with keys lun, iscsi_target, pool
        """
        req = '/san/iscsi/luns?where=name==%s' % volume_name

        LOG.debug("get luns for volume %s", volume_name)

        resp = self.rproxy.request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp['data']

        self._general_error(req, resp)

    def get_target_user(self, target_name):
        """Get name of CHAP user for accessing target

        GET
        /san/iscsi/targets/<target_name>/incoming-users

        :param target_name:
        """
        req = "/san/iscsi/targets/%s/incoming-users" % target_name

        LOG.debug("get chap cred for target %s", target_name)

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp['data']

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=target_name)

        self._general_error(req, resp)

    def delete_target_user(self, target_name, user_name):
        """Delete CHAP user for target

        DELETE
        /san/iscsi/targets/<target_name>/incoming-users/<user_name>

        :param target_name: target name
        :param user_name: user name
        """
        req = '/san/iscsi/targets/%(target)s/incoming-users/%(user)s' % {
            'target': target_name,
            'user': user_name}

        LOG.debug("remove credentails from target %s", target_name)

        # lock_path = self._lock()
        # try:
        resp = self.rproxy.pool_request('DELETE', req)
        # finally:
        #    jlock.release_target_lock(lock_path)

        if resp.get("error") is None and resp["code"] == 204:
            return

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=target_name)

        self._general_error(req, resp)

    def is_target_lun(self, target_name, lun_name, lid):
        """is_target_lun.

        GET /san/iscsi/targets/<target_name>/luns/<lun_name>
        :param target_name: target name to check
        :param lun_name: zvol name that will be used to attach to target
        :param lid: lun id of the volume assigned to target_name
        :return: Bool
        """
        req = '/san/iscsi/targets/%(tar)s/luns/%(lun)s' % {
            'tar': target_name,
            'lun': lun_name}

        LOG.debug("check if volume %(vol)s is associated with %(tar)s",
                  {'vol': lun_name,
                   'tar': target_name})
        resp = self.rproxy.pool_request('GET', req)

        if (not resp["error"] and
            resp["code"] == 200 and
                'data' in resp):
            LOG.debug(("volume %(vol)s is associated to "
                       "target %(tar)s lun %(lun)d"),
                      {'vol': lun_name,
                       'tar': target_name,
                       'lun': int(resp['data']['lun'])})
            if int(resp['data']['lun']) == lid:
                return True
            else:
                return False

        if resp['code'] == 404:
            LOG.debug("volume %(vol)s is not associated with %(tar)s",
                      {'vol': lun_name,
                       'tar': target_name})
            return False

        self._general_error(req, resp)

    def get_target_lun(self, target_name, lun_name):
        """get_target_lun.

        GET /san/iscsi/targets/<target_name>/luns/<lun_name>
        :param target_name: target name
        :param lun_name: zvol name attached to target
        :return: lun data dict
        """
        req = '/san/iscsi/targets/%(tar)s/luns/%(lun)s' % {
            'tar': target_name,
            'lun': lun_name}

        LOG.debug("get lun info for volume %(vol)s on target %(tar)s",
                  {'vol': lun_name,
                   'tar': target_name})
        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=lun_name)

        self._general_error(req, resp)

    def attach_target_vol(self, target_name, lun_name,
                          lun_id=0,
                          mode=None):
        """attach_target_vol.

        POST /san/iscsi/targets/<target_name>/luns
        :param target_name: name of the target
        :param lun_name: phisical volume name to be attached
        :param lun_id: id that would be assigned to volume
        :param mode: one of "wt", "wb" or "ro"
        :return:
        """
        req = '/san/iscsi/targets/%s/luns' % target_name

        jbody = {"name": lun_name, "lun": lun_id}
        if mode is not None:
            if mode in ['wt', 'wb', 'ro']:
                jbody['mode'] = mode
            else:
                raise jexc.JDSSException(
                    _("Incoret mode for target %s" % mode))
        LOG.debug("atach volume %(vol)s to target %(tar)s",
                  {'vol': lun_name,
                   'tar': target_name})

        # lock_path = self._lock()
        # try:
        resp = self.rproxy.pool_request('POST', req, json_data=jbody)
        # finally:
        #    jlock.release_target_lock(lock_path)

        if not resp["error"] and resp["code"] == 201:
            return resp["data"]

        if resp["error"]:
            if ('class' in resp["error"] and
                    self.class_item_conflict_error.match(
                        resp['error']['class']) and
                    'message' in resp["error"] and
                    self.message_volume_already_used.match(
                        resp['error']['message'])):
                raise jexc.JDSSResourceIsBusyException(lun_name)

        if "message" in resp["error"]:
            if self.no_space_left.match(resp["error"]["message"]):
                raise jexc.JDSSResourceExhausted

        if resp['code'] == 409:
            raise jexc.JDSSResourceExistsException(res=lun_name)

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=target_name)

        self._general_error(req, resp)

    def detach_target_vol(self, target_name, lun_name):
        """detach_target_vol.

        DELETE /san/iscsi/targets/<target_name>/luns/
        <lun_name>
        :param target_name:
        :param lun_name:
        :return:
        """
        req = '/san/iscsi/targets/%(tar)s/luns/%(lun)s' % {
            'tar': target_name,
            'lun': lun_name}

        LOG.debug("detach volume %(vol)s from target %(tar)s",
                  {'vol': lun_name,
                   'tar': target_name})

        # lock_path = self._lock()
        # try:
        resp = self.rproxy.pool_request('DELETE', req)
        # finally:
        #    jlock.release_target_lock(lock_path)

        if resp["code"] in (200, 201, 204):
            return

        if resp['code'] == 404:
            raise jexc.JDSSResourceNotFoundException(res=lun_name)

        self._general_error(req, resp)

    def create_snapshot(self, volume_name, snapshot_name):
        """create_snapshot.

        POST /pools/<string:poolname>/volumes/<string:volumename>/snapshots
        :param pool_name:
        :param volume_name: source volume
        :param snapshot_name: snapshot name
        :return:
        """
        req = '/volumes/%s/snapshots' % volume_name

        jbody = {
            'snapshot_name': snapshot_name
        }

        LOG.info("create snapshot %(snap)s for volume %(vol)s",
                 {'snap': jcom.idname(snapshot_name),
                  'vol': jcom.idname(volume_name)})

        resp = self.rproxy.pool_request('POST', req, json_data=jbody)

        if not resp["error"] and resp["code"] in (200, 201, 204):
            return

        if resp["code"] == 500:
            if resp["error"]:
                if resp["error"]["errno"] == 5:
                    raise jexc.JDSSSnapshotExistsException(
                        snapshot_name, volume_name)
                if resp["error"]["errno"] == 1:
                    raise jexc.JDSSVolumeNotFoundException(
                        volume=volume_name)

        self._general_error(req, resp)

    def create_volume_from_snapshot(self, volume_name, snapshot_name,
                                    original_vol_name, **options):
        """create_volume_from_snapshot.

        POST /volumes/<string:volumename>/clone
        :param volume_name: volume that is going to be created
        :param snapshot_name: slice of original volume
        :param original_vol_name: sample copy
        :return:
        """
        req = '/volumes/%s/clone' % original_vol_name

        jbody = {
            'name': volume_name,
            'snapshot': snapshot_name,
            'sparse': False,
        }

        if 'sparse' in options:
            jbody['sparse'] = options['sparse']

        if 'readonly' in options:
            jbody['readonly'] = options['readonly']

        LOG.info("create volume %(vol)s from snapshot %(snap)s",
                 {'vol': jcom.idname(volume_name),
                  'snap': jcom.idname(snapshot_name)})

        resp = self.rproxy.pool_request('POST', req, json_data=jbody)

        if not resp["error"] and resp["code"] in (200, 201, 204):
            return

        if resp["code"] == 500:
            if resp["error"]:
                if (resp["error"]["errno"] == 100 and
                        ('message' in resp["error"])):
                    if self.dataset_exists_msg.match(resp['error']['message']):
                        raise jexc.JDSSVolumeExistsException(volume_name)
                if resp["error"]["errno"] == 1:
                    raise jexc.JDSSResourceNotFoundException(
                        res="%(vol)s@%(snap)s" % {'vol': original_vol_name,
                                                  'snap': snapshot_name})
            if "message" in resp["error"]:
                if self.no_space_left.match(resp["error"]["message"]):
                    raise jexc.JDSSResourceExhausted

        self._general_error(req, resp)

    def delete_snapshot(self,
                        volume_name,
                        snapshot_name,
                        recursively_children=False,
                        force_umount=False):
        """delete_snapshot.

        DELETE /volumes/<string:volumename>/snapshots/
            <string:snapshotname>
        :param volume_name: volume that snapshot belongs to
        :param snapshot_name: snapshot name
        :param recursively_children: boolean indicating if zfs should
            recursively destroy all children of resource, in case of snapshot
            remove all snapshots in descendant file system (default false).
        :param recursively_dependents: boolean indicating if zfs should
            recursively destroy all dependents, including cloned file systems
            outside the target hierarchy (default false).
        :param force_umount: boolean indicating if volume should be forced to
            umount (defualt false).
        :return:
        """

        req = '/volumes/%(vol)s/snapshots/%(snap)s' % {
            'vol': volume_name,
            'snap': snapshot_name}

        jbody = {}
        if recursively_children:
            jbody['recursively_children'] = True

        if force_umount:
            jbody['force_umount'] = True

        LOG.info(("delete snapshot: %(snap)s for volume: %(vol)s"
                  " recursively" if recursively_children else ""
                  " with unmounting" if force_umount else ""),
                 {'vol': jcom.idname(volume_name),
                  'snap': jcom.idname(snapshot_name)})

        resp = self.rproxy.pool_request('DELETE', req, json_data=jbody)

        if resp["code"] in (200, 201, 204):
            LOG.debug("snapshot %s deleted", snapshot_name)
            return

        if resp["code"] == 500:
            if resp["error"]:
                if resp["error"]["errno"] == 1000:
                    raise jexc.JDSSSnapshotIsBusyException(
                        snapshot=snapshot_name)
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(snapshot_name)
        self._general_error(req, resp)

    def get_snapshot(self, volume_name, snapshot_name):

        req = (('/volumes/%(vol)s/snapshots/%(snap)s') %
               {'vol': volume_name, 'snap': snapshot_name})

        LOG.debug("get snapshots for volume %s ", volume_name)

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]

        if resp['code'] == 500:
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(volume_name)

        self._general_error(req, resp)

    def get_snapshots(self, volume_name):
        """get_snapshots.

        GET
        /volumes/<string:volumename>/
            snapshots

        :param volume_name: that snapshot belongs to
        :return:
        {
            "data":
            [
                {
                    "referenced": "65536",
                    "name": "MySnapshot",
                    "defer_destroy": "off",
                    "userrefs": "0",
                    "primarycache": "all",
                    "type": "snapshot",
                    "creation": "2015-5-27 16:8:35",
                    "refcompressratio": "1.00x",
                    "compressratio": "1.00x",
                    "written": "65536",
                    "used": "0",
                    "clones": "",
                    "mlslabel": "none",
                    "secondarycache": "all"
                }
            ],
            "error": null
        }
        """
        req = '/volumes/%s/snapshots' % volume_name

        LOG.debug("get snapshots for volume %s ", volume_name)

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]["entries"]

        if resp['code'] == 500:
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(volume_name)

        self._general_error(req, resp)

    def get_snapshot_clones(self, volume_name, snapshot_name):
        """get_snapshot_clones.

        GET
        /volumes/<string:volumename>/snapshot/<string:snapname>/clones

        :param volume_name: that snapshot belongs to
        :return:
        {
            "data":
            [
                {
                    "name": "se_snap1_OZWS2NBSGAWWI2LTNMWTA---",
                    "full_name": "Pool-2/se_snap1_OZWS2NBSGAWWI2LTNMWTA---",
                    "is_clone": true
                }
            ],
            "error": null
        }
        """
        req = "/volumes/%(vol)s/snapshots/%(snap)s/clones" % {
            "vol": volume_name, "snap": snapshot_name}

        LOG.debug("get snapshot %(vol)s clones for volume %(snap)s",
                  {'vol': jcom.idname(volume_name),
                   'snap': jcom.idname(snapshot_name)})

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]

        if resp['code'] == 500:
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(volume_name)

        self._general_error(req, resp)

    def get_nas_snapshot_clone(self, volume_name, snapshot_name, clone_name):
        """get_nas_snapshot_clones.

        GET
        /volumes/<string:volumename>/snapshot/<string:snapname>/clones/<string:clone_name>

        :param volume_name: that snapshot belongs to
        :return:
        {
                "name": "sp_102_vm-102-disk-0_raw_snap1_GEYDEL3WNUWTCMBSFVSGS43LFUYC44TBO4------_ONXGC4BR_ORSXG5BS",
                "full_name": "Pool-2/sp_102_vm-102-disk-0_raw_snap1_GEYDEL3WNUWTCMBSFVSGS43LFUYC44TBO4------_ONXGC4BR_ORSXG5BS",
                "origin": "Pool-2/test2@sp_102_vm-102-disk-0_raw_snap1_GEYDEL3WNUWTCMBSFVSGS43LFUYC44TBO4------_ONXGC4BR_ORSXG5BS",
                "quota": null,
                "refquota": null,
                "dedup": "off",
                "compression": "off",
                "sync": "standard",
                "logbias": "latency",
                "primarycache": "all",
                "secondarycache": "all",
                "atime": "on",
                "copies": "1",
                "reservation": null,
                "refreservation": null,
                "recordsize": "131072",
                "used": "8192",
                "special_small_blocks": "0",
                "available": "265688629248",
                "usedbysnapshots": "0",
                "usedbydataset": "8192",
                "usedbychildren": "0",
                "logicalused": "4096",
                "logicalreferenced": "22001085952",
                "snapshot_count": 0,
                "clones": null,
                "creation": "1771223618",
                "readonly": "off",
                "canmount": "on",
                "property_source": {
                  "special_small_blocks": {
                    "is_local": false,
                    "inherited_from": null
                  }
                }
              },
              "error": null
        }
        """
        req = "/nas-volumes/%(vol)s/snapshots/%(snap)s/clones/%(clone)s" % {
            "vol": volume_name, "snap": snapshot_name, "clone": clone_name}

        LOG.debug("get nas-volume %(vol)s snapshot %(snap)s clone %(clone)s",
                  {'vol': jcom.idname(volume_name),
                   'snap': jcom.idname(snapshot_name),
                   'clone': jcom.idname(clone_name)})

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]

        if resp['code'] == 500:
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(volume_name)

        self._general_error(req, resp)

    def get_nas_snapshot_clones(self, volume_name, snapshot_name):
        """get_nas_snapshot_clones.

        GET
        /volumes/<string:volumename>/snapshot/<string:snapname>/clones

        :param volume_name: that snapshot belongs to
        :return:
        {
            "data":
            [
                {
                    "name": "se_snap1_OZWS2NBSGAWWI2LTNMWTA---",
                    "full_name": "Pool-2/se_snap1_OZWS2NBSGAWWI2LTNMWTA---",
                    "is_clone": true
                }
            ],
            "error": null
        }
        """
        req = "/nas-volumes/%(vol)s/snapshots/%(snap)s/clones" % {
            "vol": volume_name, "snap": snapshot_name}

        LOG.debug("get nas snapshot %(vol)s clones for dataset %(snap)s",
                  {'vol': jcom.idname(volume_name),
                   'snap': jcom.idname(snapshot_name)})

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]

        if resp['code'] == 500:
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(volume_name)

        self._general_error(req, resp)

    def get_snapshots_page(self, page_id):
        """get_snapshots_page

        GET
        /volumes/snapshots?page=<int:page_id>

        :param page_id: page number
        :return:
        {
            "data":
            [
                {"results": 1,
                 "entries": [
                     ]}
                {
                    "referenced": "65536",
                    "name": "MySnapshot",
                    "defer_destroy": "off",
                    "userrefs": "0",
                    "primarycache": "all",
                    "type": "snapshot",
                    "creation": "2015-5-27 16:8:35",
                    "refcompressratio": "1.00x",
                    "compressratio": "1.00x",
                    "written": "65536",
                    "used": "0",
                    "clones": "",
                    "mlslabel": "none",
                    "secondarycache": "all"
                }
            ],
            "error": null
        }
        """
        req = '/volumes/snapshots?page=%s' % str(page_id)

        LOG.debug("get page %d of all snapshots", page_id)

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]["entries"]

        self._general_error(req, resp)

    def get_volume_snapshots_page(self, vname, page_id):
        """get_snapshots_page

        GET
        /volumes/snapshots?page=<int:page_id>

        :param page_id: page number
        :return:
        {
            "data":
            [
                {"results": 1,
                 "entries": [
                     ]}
                {
                    "referenced": "65536",
                    "name": "MySnapshot",
                    "defer_destroy": "off",
                    "userrefs": "0",
                    "primarycache": "all",
                    "type": "snapshot",
                    "creation": "2015-5-27 16:8:35",
                    "refcompressratio": "1.00x",
                    "compressratio": "1.00x",
                    "written": "65536",
                    "used": "0",
                    "clones": "",
                    "mlslabel": "none",
                    "secondarycache": "all"
                }
            ],
            "error": null
        }
        """
        req = (('/volumes/%(vname)s/snapshots?page=%(page)s') %
               {'vname': vname, 'page': str(page_id)})

        LOG.debug("get page %d of volume %s snapshots", page_id, vname)

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]["entries"]

        if resp['error']:
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(res=vname)
            if 'class' in resp['error']:
                if self.class_item_not_found_error.match(resp['error']['class']):
                    raise jexc.JDSSResourceNotFoundException(res=vname)

        self._general_error(req, resp)

    def get_nas_volume_snapshots_page(self, vname, page_id):
        """get_snapshots_page

        GET
        /nas-volumes/<nas-vol vname>snapshots?page=<int:page_id>

        :param page_id: page number
        :return:
        {
            "data":
            [
                {"results": 1,
                 "entries": [
                     ]}
                {
                    "referenced": "65536",
                    "name": "MySnapshot",
                    "defer_destroy": "off",
                    "userrefs": "0",
                    "primarycache": "all",
                    "type": "snapshot",
                    "creation": "2015-5-27 16:8:35",
                    "refcompressratio": "1.00x",
                    "compressratio": "1.00x",
                    "written": "65536",
                    "used": "0",
                    "clones": "",
                    "mlslabel": "none",
                    "secondarycache": "all"
                }
            ],
            "error": null
        }
        """
        req = (('/nas-volumes/%(vname)s/snapshots?page=%(page)s') %
               {'vname': vname, 'page': str(page_id)})

        LOG.debug("get page %d of volume %s snapshots", page_id, vname)

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]["entries"]

        if resp['error']:
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(res=vname)

        self._general_error(req, resp)

    def get_pool_stats(self):
        """get_pool_stats.

        GET /pools/<string:poolname>
        :param pool_name:
        :return:
        {
          "data": {
            "available": "24433164288",
            "status": 24,
            "name": "Pool-0",
            "scan": {
              "errors": 0,
              "repaired": "0",
              "start_time": 1463476815,
              "state": "finished",
              "end_time": 1463476820,
              "type": "scrub"
            },
            "iostats": {
              "read": "0",
              "write": "0",
              "chksum": "0"
            },
            "vdevs": [
              {
                "name": "scsi-SSCST_BIOoWKF6TM0qafySQBUd1bb392e",
                "iostats": {
                  "read": "0",
                  "write": "0",
                  "chksum": "0"
                },
                "disks": [
                  {
                    "led": "off",
                    "name": "sdb",
                    "iostats": {
                      "read": "0",
                      "write": "0",
                      "chksum": "0"
                    },
                    "health": "ONLINE",
                    "sn": "d1bb392e",
                    "path": "pci-0000:04:00.0-scsi-0:0:0:0",
                    "model": "oWKF6TM0qafySQBU",
                    "id": "scsi-SSCST_BIOoWKF6TM0qafySQBUd1bb392e",
                    "size": 30064771072
                  }
                ],
                "health": "ONLINE",
                "vdev_replacings": [],
                "vdev_spares": [],
                "type": ""
              }
            ],
            "health": "ONLINE",
            "operation": "none",
            "id": "11612982948930769833",
            "size": "29796335616"
          },
          "error": null
        }
        """
        req = ""
        LOG.debug("Get pool %s fsprops", self.pool)

        resp = self.rproxy.pool_request('GET', req)
        if not resp["error"] and resp["code"] == 200:
            return resp["data"]

        if ("class" in resp['error'] and
                self.class_item_not_found_error.match(resp['error']['class'])):
            raise jexc.JDSSResourceNotFoundException(res="pool %s" % self.pool)
        self._general_error(req, resp)

    def get_snapshot_rollback(self, volume_name, snapshot_name):
        """get snapshot rollback fetches number of resources affected by
        volume rollback to specific snapshot

        GET /volumes/<volume_name>/snapshots/<snapshot_name>/rollback

        :param str volume_name: volume that is going to be reverted
        :param str snapshot_name: snapshot of a volume above

        :return: { 'clones': int, 'snapshots': int }
        """
        req = (('/volumes/%(vname)s/snapshots/%(sname)s/rollback') %
               {'vname': volume_name, 'sname': snapshot_name})

        LOG.info(("check rollback dependency count for volume %(vol)s"
                 " to snapshot %(snap)s"),
                 {'vol': jcom.idname(volume_name),
                  'snap': jcom.idname(snapshot_name)})

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]

        if resp["code"] == 500:
            if resp["error"]:
                if resp["error"]["errno"] == 1:
                    raise jexc.JDSSResourceNotFoundException(
                        res="%(vol)s@%(snap)s" % {'vol': volume_name,
                                                  'snap': snapshot_name})

        self._general_error(req, resp)

    def snapshot_rollback(self, volume_name, snapshot_name):
        """snapshot rollback rollbacks volume to its snapshot

        POST /volumes/<volume_name>/snapshots/<snapshot_name>/rollback
        :param volume_name: volume that is going to be restored
        :param snapshot_name: snapshot of a volume above
        :return:
        """
        req = (('/volumes/%(vname)s/snapshots/%(sname)s/rollback') %
               {'vname': volume_name, 'sname': snapshot_name})

        LOG.info("rollback volume %(vol)s to snapshot %(snap)s",
                 {'vol': jcom.idname(volume_name),
                  'snap': jcom.idname(snapshot_name)})

        resp = self.rproxy.pool_request('POST', req)

        if resp["code"] in (200, 201, 204):
            LOG.debug("volume %s been rolled back to snapshot %s",
                      volume_name,
                      snapshot_name)
            return

        self._general_error(req, resp)

    def get_nas_volume(self, nas_volume):
        """get_nas_volume
        GET /nas-volumes/<nas_volume>
        :return:
        """
        req = '/nas-volumes/' + nas_volume
        LOG.debug("get nas volume %s", str(nas_volume))
        resp = self.rproxy.pool_request('GET', req)
        if not resp["error"] and resp["code"] == 200:
            return resp['data']
        if resp['error']:
            if 'message' in resp['error']:
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(res=nas_volume)
        self._general_error(req, resp)

    def get_nas_volumes(self):
        """get_nas_volumes
        GET /nas-volumes
        List all NAS volumes (datasets) in the pool
        :return: list of NAS volumes
        """
        req = '/nas-volumes'
        LOG.debug("get all nas volumes")
        resp = self.rproxy.pool_request('GET', req)
        if not resp["error"] and resp["code"] in (200, 201):
            return resp['data']
        self._general_error(req, resp)

    def create_nas_volume(self, volume_name, quota,
                          reservation=None):
        """create_nas_volumes.
        POST
        .../nas_volumes
        :param volume_name:
        :param volume_size:
        :return:
        """
        jbody = {
            'name': str(volume_name),
            # Maximal size of volume
            'quota': str(quota)
        }

        if reservation:
            jbody['reservation'] = str(reservation)

        req = '/nas-volumes'

        LOG.info("create nas volume %s", str(jcom.idname(volume_name)))
        resp = self.rproxy.pool_request('POST', req, json_data=jbody)

        if not resp["error"] and resp["code"] in (200, 201):
            return resp["data"]

        if "error" in resp and resp["error"] is not None:
            if "message" in resp["error"]:
                if self.no_space_left.match(resp["error"]["message"]):
                    raise jexc.JDSSResourceExhausted
                if self.dataset_exists_msg.match(resp["error"]["message"]):
                    raise jexc.JDSSVolumeExistsException(volume_name)
                if self.resource_already_exists_msg.match(
                        resp["error"]["message"]):
                    raise jexc.JDSSVolumeExistsException(volume_name)
                if self.message_dataset_do_not_exist.match(
                        resp['error']['message']):
                    raise jexc.JDSSPoolNotFoundException(self.pool)

        self._general_error(req, resp)

    def delete_nas_volume(self, volume_name):
        """delete_nas_volumes.

        POST
        .../nas_volumes

        :param volume_name:
        :param volume_size:
        :return:
        """
        req = '/nas-volumes/' + volume_name

        LOG.info("delete nas-volume %s", volume_name)

        resp = self.rproxy.pool_request('DELETE', req, json_data={})

        if resp["code"] in (200, 201, 204):
            LOG.debug(
                "nas volume %s deleted", volume_name)
            return

        not_found_err = "opene.exceptions.ItemNotFoundError"
        if (resp["code"] == 404) or \
                (resp["error"]["class"] == not_found_err):
            raise jexc.JDSSResourceNotFoundException(res=volume_name)

        self._general_error(req, resp)

    def get_share(self, share):
        req = '/shares/' + share

        LOG.debug("get share %s", share)

        resp = self.rproxy.request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp['data']

        not_found_err = "opene.exceptions.ItemNotFoundError"
        if (resp["code"] == 404) or \
                (resp["error"]["class"] == not_found_err):
            raise jexc.JDSSResourceNotFoundException(res=share)

        self._general_error(req, resp)

    def create_share(self, share_name, path,
                     active=False,
                     proto='nfs',
                     insecure_connections=False,
                     synchronous_data_record=True,
                     insecure_lock_requests=False,
                     all_squash=False,
                     no_root_squash=False,
                     allow_access_ip=None):
        req = '/shares'

        LOG.info("create share %s with path %s", share_name, path)

        json_data = {}
        if proto.lower() == 'nfs':
            nfs_flags = {"enabled": True,
                         "insecure_connections": insecure_connections,
                         "synchronous_data_record": synchronous_data_record,
                         "insecure_lock_requests": insecure_lock_requests,
                         "all_squash": all_squash,
                         "no_root_squash": no_root_squash}

            if allow_access_ip is not None:
                nfs_flags["allow_access_ip"] = allow_access_ip

            json_data = {"path": path,
                         "name": share_name,
                         "active": active,
                         "nfs": nfs_flags}

        else:
            json_data = {"path": path,
                         "name": share_name,
                         "smb": {"enabled": True,
                                 "visible": True,
                                 "access_mode": "user"}}

        resp = self.rproxy.request('POST', req, json_data=json_data)

        if resp["code"] == 409:
            if resp["error"]:
                if resp["error"].get("errno") == 1:
                    raise jexc.JDSSResourceExistsException(
                        res=share_name)
        if resp['code'] == 201:
            return

        self._general_error(req, resp)

    def delete_share(self, sharename):
        req = '/shares/' + sharename

        LOG.info("delete share %s", sharename)

        resp = self.rproxy.request('DELETE', req)

        if resp['code'] == 204:
            return
        if (('class' in resp.get('error', {})) and
                ('message' in resp.get('error', {}))):
            if (self.class_werkzeug_notfound.match(resp['error']['class']) and
                    self.message_share_not_exists_msg.match(resp['error']['message'])):
                raise jexc.JDSSResourceNotFoundException(sharename)

        self._general_error(req, resp)

    def create_nas_snapshot(self, dataset_name, snapshot_name):
        """create_nas_snapshot.

        POST /pools/<poolname>/nas-volumes/<datasetname>/snapshots
        :param dataset_name: NAS volume (dataset) name
        :param snapshot_name: snapshot name
        :return:
        """
        req = '/nas-volumes/%s/snapshots' % dataset_name

        jbody = {
            'name': snapshot_name
        }

        LOG.info("create snapshot %(snap)s for NAS volume %(vol)s",
                 {'snap': jcom.idname(snapshot_name),
                  'vol': jcom.idname(dataset_name)})

        resp = self.rproxy.pool_request('POST', req, json_data=jbody)

        if not resp["error"] and resp["code"] in (200, 201, 204):
            return

        if resp["code"] == 500:
            if resp["error"]:
                if resp["error"].get("errno") == 5:
                    raise jexc.JDSSSnapshotExistsException(
                        snapshot_name, dataset_name)
                if resp["error"].get("errno") == 1:
                    raise jexc.JDSSResourceNotFoundException(
                        res=dataset_name)

        self._general_error(req, resp)

    def delete_nas_snapshot(self, dataset_name, snapshot_name):
        """delete_nas_snapshot.

        DELETE /pools/<poolname>/nas-volumes/<datasetname>/
            snapshots/<snapshotname>
        :param dataset_name: NAS volume (dataset) name
        :param snapshot_name: snapshot name
        :return:
        """

        req = '/nas-volumes/%(vol)s/snapshots/%(snap)s' % {
            'vol': dataset_name,
            'snap': snapshot_name}

        LOG.info("delete snapshot %(snap)s for NAS volume %(vol)s",
                 {'vol': jcom.idname(dataset_name),
                  'snap': jcom.idname(snapshot_name)})

        resp = self.rproxy.pool_request('DELETE', req, json_data={})

        if resp["code"] in (200, 201, 204):
            LOG.debug("snapshot %s deleted", snapshot_name)
            return

        if resp["code"] == 500:
            if resp["error"]:
                if resp["error"].get("errno") == 1000:
                    raise jexc.JDSSSnapshotIsBusyException(
                        snapshot=snapshot_name)
            if 'message' in resp.get('error', {}):
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(snapshot_name)

        self._general_error(req, resp)

    def get_nas_snapshot(self, dataset_name, snapshot_name):
        """get_nas_snapshot.

        GET /pools/<poolname>/nas-volumes/<datasetname>/
            snapshots/<snapshotname>
        :param dataset_name: NAS volume (dataset) name
        :param snapshot_name: snapshot name
        :return: snapshot data
        """

        req = '/nas-volumes/%(vol)s/snapshots/%(snap)s' % {
            'vol': dataset_name,
            'snap': snapshot_name}

        LOG.debug("get snapshot %s for NAS volume %s",
                  snapshot_name, dataset_name)

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]

        if resp['code'] == 500:
            if 'message' in resp.get('error', {}):
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(dataset_name)

        self._general_error(req, resp)

    def get_nas_snapshots(self, dataset_name):
        """get_nas_snapshots.

        GET /pools/<poolname>/nas-volumes/<datasetname>/snapshots
        :param dataset_name: NAS volume (dataset) name
        :return: list of snapshots
        """
        req = '/nas-volumes/%s/snapshots' % dataset_name

        LOG.debug("get snapshots for NAS volume %s", dataset_name)

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]

        if resp['code'] == 500:
            if 'message' in resp.get('error', {}):
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(dataset_name)

        self._general_error(req, resp)

    def create_nas_clone(self, dataset_name, snapshot_name, clone_name,
                         **options):
        """create_nas_clone.

        POST /pools/<poolname>/nas-volumes/<datasetname>/
            snapshots/<snapshotname>/clones
        :param dataset_name: NAS volume (dataset) name
        :param snapshot_name: snapshot name
        :param clone_name: name for the new clone
        :param options: optional ZFS properties (compression, copies, etc.)
        :return:
        """
        req = '/nas-volumes/%(vol)s/snapshots/%(snap)s/clones' % {
            'vol': dataset_name,
            'snap': snapshot_name}

        jbody = {
            'name': clone_name
        }

        # Add optional ZFS properties
        for key in ['copies', 'compression', 'primarycache', 'logbias',
                    'atime', 'dedup', 'secondarycache', 'sync']:
            if key in options:
                jbody[key] = options[key]

        LOG.info("create clone %(clone)s from snapshot %(snap)s "
                 "of NAS volume %(vol)s",
                 {'clone': jcom.idname(clone_name),
                  'snap': jcom.idname(snapshot_name),
                  'vol': jcom.idname(dataset_name)})

        resp = self.rproxy.pool_request('POST', req, json_data=jbody)

        if not resp["error"] and resp["code"] in (200, 201, 204):
            return resp.get("data")

        if resp["code"] == 500:
            if resp["error"]:
                if 'message' in resp["error"]:
                    if self.dataset_exists_msg.match(
                            resp['error']['message']):
                        raise jexc.JDSSResourceExistsException(clone_name)
                    if self.resource_dne_msg.match(
                            resp['error']['message']):
                        raise jexc.JDSSResourceNotFoundException(
                            res="%(vol)s@%(snap)s" % {
                                'vol': dataset_name,
                                'snap': snapshot_name})
                    if self.no_space_left.match(resp["error"]["message"]):
                        raise jexc.JDSSResourceExhausted

        self._general_error(req, resp)

    def delete_nas_clone(self, dataset_name, snapshot_name, clone_name):
        """delete_nas_clone.

        DELETE /pools/<poolname>/nas-volumes/<datasetname>/
            snapshots/<snapshotname>/clones/<clonename>
        :param dataset_name: NAS volume (dataset) name
        :param snapshot_name: snapshot name
        :param clone_name: clone name to delete
        :return:
        """

        req = '/nas-volumes/%(vol)s/snapshots/%(snap)s/clones/%(clone)s' % {
            'vol': dataset_name,
            'snap': snapshot_name,
            'clone': clone_name}

        LOG.info("delete clone %(clone)s from snapshot %(snap)s "
                 "of NAS volume %(vol)s\n"
                 "clone repr: %(clone_repr)s\n"
                 "snap  repr: %(snap_repr)s\n",
                 {'clone': jcom.idname(clone_name),
                  'snap': jcom.idname(snapshot_name),
                  'vol': jcom.idname(dataset_name),
                  'clone_repr': repr(clone_name),
                  'snap_repr': repr(snapshot_name)})

        LOG.info("req url: %(url)s",
                 {'url': repr(req)})
        resp = self.rproxy.pool_request('DELETE', req, json_data={})

        if resp["code"] in (200, 201, 204):
            LOG.debug("clone %s deleted", clone_name)
            return

        if resp["code"] == 500:
            if 'message' in resp.get('error', {}):
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(clone_name)
        if (('class' in resp.get('error', {})) and
                ('message' in resp.get('error', {}))):
            if (self.class_werkzeug_notfound.match(resp['error']['class']) and
                    self.message_clone_not_exists_msg.match(resp['error']['message'])):
                raise jexc.JDSSResourceNotFoundException(clone_name)
        self._general_error(req, resp)

    def get_nas_clones(self, dataset_name, snapshot_name):
        """get_nas_clones.

        GET /pools/<poolname>/nas-volumes/<datasetname>/
            snapshots/<snapshotname>/clones
        :param dataset_name: NAS volume (dataset) name
        :param snapshot_name: snapshot name
        :return: list of clones
        """
        req = '/nas-volumes/%(vol)s/snapshots/%(snap)s/clones' % {
            'vol': dataset_name,
            'snap': snapshot_name}

        LOG.debug("get clones for snapshot %s of NAS volume %s",
                  snapshot_name, dataset_name)

        resp = self.rproxy.pool_request('GET', req)

        if not resp["error"] and resp["code"] == 200:
            return resp["data"]

        if resp['code'] == 500:
            if 'message' in resp.get('error', {}):
                if self.resource_dne_msg.match(resp['error']['message']):
                    raise jexc.JDSSResourceNotFoundException(
                        "%(vol)s@%(snap)s" % {
                            'vol': dataset_name,
                            'snap': snapshot_name})

        self._general_error(req, resp)

    def get_shares_page(self, page_id):
        """get_all_pool_volumes.

        GET
        /pools/<string:poolname>/volumes
        :param pool_name
        :return list of all pool volumes
        """
        req = '/shares?page=%s&per_page=100' % str(page_id)

        LOG.debug("get 100 shares from page %s", page_id)
        resp = self.rproxy.request('GET', req)

        if resp['error'] is None and resp['code'] == 200:
            return resp['data']['entries']
        self._general_error(req, resp)

    def get_targets_page(self, page_id):
        """get_all_pool_volumes.

        GET
        /pools/<string:poolname>/volumes
        :param pool_name
        :return list of all pool volumes
        """
        # TODO: cehck page=0&per_page=0&sort_by=name&order=asc
        req = '/san/iscsi/targets?page=%s&per_page=25' % str(page_id)

        LOG.debug("get 100 targets from page %s", page_id)
        resp = self.rproxy.pool_request('GET', req, apiv=4)

        if resp['error'] is None and resp['code'] == 200:
            if 'data' in resp:
                return resp['data']['entries']
        self._general_error(req, resp)

    def extend_nas_volume(self, nas_volume, nas_volume_quota):
        """create_volume.

        PUT /nas-volumes/<string:volume_name>
        """
        req = '/nas-volumes/' + nas_volume
        nas_volume_quota_str = str(nas_volume_quota)
        jbody = {
            'quota': nas_volume_quota_str
        }

        LOG.info("extend nas-volume %(volume)s to %(size)s",
                 {"volume": jcom.idname(nas_volume),
                  "size": nas_volume_quota_str})
        resp = self.rproxy.pool_request('PUT', req, json_data=jbody)

        if not resp["error"] and resp["code"] == 201:
            return

        if resp["error"]:
            raise jexc.JDSSRESTException(req,
                                         _('Failed to extend nas-volume %s' %
                                           nas_volume))

        self._general_error(req, resp)

    def get_pool_vips(self):
        """Return list of VIP deffinitions for current pool."""
        req = '/vips'
        LOG.info("get vips")
        resp = self.rproxy.pool_request('GET', req)
        if not resp["error"] and resp["code"] == 200:
            return resp['data']

        self._general_error(req, resp)
