
def do_nothing(arg):
    return arg

_ = do_nothing
